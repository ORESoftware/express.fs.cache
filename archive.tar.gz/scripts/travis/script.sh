#!/usr/bin/env bash


echo "this is the travis 'script' script."